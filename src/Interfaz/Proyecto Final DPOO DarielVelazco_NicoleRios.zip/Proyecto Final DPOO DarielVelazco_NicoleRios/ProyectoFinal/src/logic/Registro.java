package logic;

import java.time.LocalDate;
import java.time.LocalTime;

public class Registro { 
    private Persona persona;
    private Local local;
    private LocalTime horaEntrada;
    private LocalTime horaSalida; 
    private LocalDate fecha;

    public Registro(Persona persona, Local local) { 
        setPersona(persona);
        setLocal(local); 
        this.horaEntrada = LocalTime.now();
        this.fecha = LocalDate.now();

    }
    

    
    public void setHoraSalida(LocalTime horaSalida) {
		this.horaSalida = horaSalida;
	}

	public LocalTime getHoraSalida(){
    	return horaSalida;
    }

	public LocalTime getHoraEntrada() {
		return horaEntrada;
	}

	public void setHoraEntrada(LocalTime horaEntrada) {
		this.horaEntrada = horaEntrada;
	}

	public Persona getPersona() {
        return persona;
    }

    public Local getLocal() {
        return local;
    }



    public LocalDate getFecha() {
        return fecha;
    }

    public void setPersona(Persona persona) {
        if(persona != null)
            this.persona = persona;
        else
            throw new IllegalArgumentException("Persona no puede ser nula");
    }

    public void setLocal(Local local) {
        if(local != null)
            this.local = local;
        else
            throw new IllegalArgumentException("Local no puede ser nulo");
    }
    
    public void setFecha(LocalDate fecha) {
          this.fecha = fecha;
  }
}

