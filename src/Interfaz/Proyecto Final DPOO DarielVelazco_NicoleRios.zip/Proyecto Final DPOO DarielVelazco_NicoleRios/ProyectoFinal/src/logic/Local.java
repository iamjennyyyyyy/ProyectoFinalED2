package logic;

import enums.TipoLocal;

public class Local {
	private String codigo;
	private TipoLocal tipo;
	private Persona responsable;

	public Local(String codigo, TipoLocal tipo, Persona responsable) {
		setTipo(tipo);
		setCodigo(codigo);	
		setResponsable(responsable);
	}

	public Local() {
		// TODO Auto-generated constructor stub
	}

	public String getCodigo() {
	
		return codigo;
	}

	public TipoLocal getTipo() {
		return tipo;
	}

	public Persona getResponsable() {
		return responsable;
	}

	public void setCodigo(String codigo) {
		if (codigo != null && !codigo.replaceAll(" ", "").equals("")) {
			this.codigo = codigo ;
		}else
			throw new IllegalArgumentException("El codigo del local no puede estar vacio.");
	}

	public void setTipo(TipoLocal tipo) {
		if (tipo != null) {
			this.tipo = tipo;
		}else
			throw new IllegalArgumentException("El nombre del tipo de local no puede ser nulo.");
	}

	public void setResponsable(Persona responsable) {
		if(responsable == null)
			throw new IllegalArgumentException("Responsable no puede ser nulo");
		boolean esResponsable = responsable instanceof Directivo || responsable instanceof Profesor || responsable instanceof Administrativo ||
				responsable instanceof Especialista;
		if(!esResponsable)
			throw new IllegalArgumentException("El responsable no puede ser un estudiante o un tecnico");
		else 
			this.responsable = responsable;
	}
	
	public String toString(){
		return tipo.toString()+" "+codigo;
	}


}
