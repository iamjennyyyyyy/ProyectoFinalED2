package enums;

public enum Plaza {
	Asesor, Secretaria
}
