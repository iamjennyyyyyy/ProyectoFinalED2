package enums;

public enum CargoDirectivo {
	Decano, Vicedecano, Jefe_Departamento, Secretaria_Docente
}
