package enums;

public enum AreaDirectivo {
	Decanato, Vicedecanato, Secretaria, Departamento
}
