package enums;

public enum TipoLocal {
	Decano, Vicedecano, Jefe_Departamento, Servidores, Area_Administrativa, Profesores,
	Especialistas, Estudiantes, Aula, Laboratorio
}
