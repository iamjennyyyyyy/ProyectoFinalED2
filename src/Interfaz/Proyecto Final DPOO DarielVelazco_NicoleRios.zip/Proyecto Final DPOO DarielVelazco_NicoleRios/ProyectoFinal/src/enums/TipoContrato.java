package enums;

public enum TipoContrato {
	Determinado, Indeterminado
}
