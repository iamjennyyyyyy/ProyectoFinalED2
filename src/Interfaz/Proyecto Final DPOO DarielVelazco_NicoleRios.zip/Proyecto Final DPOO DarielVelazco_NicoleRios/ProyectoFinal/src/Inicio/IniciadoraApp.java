package Inicio;

import javax.swing.JDialog;

import test.DatosPrueba;
import GUI.BarraDeCarga;
import GUI.IniciarSesion;

public class IniciadoraApp {

	public static void main(String[] args) {
		DatosPrueba.iniciar();
		BarraDeCarga dialog = new BarraDeCarga();
		dialog.setVisible(true);
		dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		
		 IniciarSesion inicio = new IniciarSesion();
		
		
		try {
			for(int i = 0; i < 100; i++){
				Thread.sleep(20);
				dialog.progressBar.setValue(i);;
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		dialog.setVisible(false);
		inicio.setVisible(true);
		dialog.dispose();

	}

}
